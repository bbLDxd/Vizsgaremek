<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "users";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM users WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
if ($user = $result->fetch_assoc()) {
    if (password_verify($password, $user['jelszo'])) {
        $_SESSION['username'] = $user['vezeteknev'] . ' ' . $user['keresztnev'];
    } else {
        $error = "Hibás jelszó.";
    }
}

if (!empty($error)) {
    echo "<p>$error</p>";
}
$userdata = null;
if (isset($_SESSION['email'])) {
    $email = $_SESSION['email'];
    $sql = "SELECT vezeteknev, keresztnev, email, utolso_belepes, regisztracio_datuma FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($user = $result->fetch_assoc()) {
        $userdata = $user;
    }
}
$sql_keszleten = "SELECT * FROM termekek";
$result_keszleten = $conn->query($sql_keszleten);

?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Főoldal</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<style>
	body {
		font-family: Arial, sans-serif;
		margin: 0;
		padding: 0;
		background-image: url('img/hatterkaka1.png');
		background-size: cover;
		background-repeat: no-repeat;
		background-attachment: fixed;
		background-position: center center;
		background-color: #f4f4f4;
		padding-bottom: 50px;
	}

	header {
		background-color: #808080;
		color: #fff;
		padding: 20px;
		text-align: center;
	}

	.logo-container img {
		height: 100px;
	}

	.cart-icon {
		cursor: pointer;
		position: fixed;
		right: 20px;
		top: 20px;
		background-color: #007bff;
		color: white;
		padding: 10px 15px;
		border-radius: 5px; 
		font-size: 24px;
	}

	.user-info {
		position: fixed;
		left: 0;
		top: 80px;
		background: #333;
		color: #fff;
		padding: 10px;
		box-shadow: 0 4px 8px rgba(0,0,0,0.3);
		width: 250px;
	}

	nav {
		display: flex;
		justify-content: center;
		background-color: #333;
		padding: 10px 0;
	}

	nav a {
		color: white;
		text-decoration: none;
		margin: 0 20px;
		font-weight: bold;
	}

	.grid-container {
		display: grid;
		grid-template-columns: repeat(5, 1fr);
    gap: 30px;
    padding: 20px;
    margin: auto;
	}

	.product {
    background-color: #DCDCDC;
    border: 1px solid #ccc;
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 4px 6px rgba(0,0,0,0.2);
    text-align: center;
    transition: transform 0.3s ease-in-out;
}

	.product:hover {
		transform: translateY(-5px);
		box-shadow: 0 6px 12px rgba(0,0,0,0.3);
	}

	.product img {
		max-width: 100%;
		height: auto;
		border-radius: 5px;
	}

	.add-to-cart {
		background-color: #28a745;
		color: white;
		padding: 10px 20px;
		border: none;
		cursor: pointer;
		display: block;
		width: auto;
		margin: 20px auto;
		border-radius: 5px;
		font-size: 18px;/
		transition: background-color 0.2s;
	}

	.add-to-cart:hover {
		background-color: #218838;
	}
	/* Reszponzív dizájnhoz */
	@media (max-width: 1200px) {
		.grid-container {
			grid-template-columns: repeat(4, 1fr);
		}
	}

@media (max-width: 768px) {
    .grid-container {
        grid-template-columns: repeat(2, 1fr);
    }

    .logo-container img {
        height: 80px;
    }

    .cart-icon {
        top: 10px;
        right: 10px;
        padding: 5px 10px;
    }

    .user-info {
        top: 100px;
        padding: 5px;
        width: 150px;
    }
}

		#cartModal {
			position: fixed;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
			width: 90%;
			max-width: 500px;
			background-color: #fff;
			padding: 20px;
			box-shadow: 0 4px 8px rgba(0,0,0,0.2);
			overflow-y: auto;
			border-radius: 10px;
			z-index: 1050;
			display: none;
		}
		.cart-content {
			background-color: #808080;
			padding: 10px;
			border-radius: 5px;
		}

		.modal-content {
			margin: auto;
		}

		.close-button {
			color: #aaaaaa;
			float: right;
			font-size: 28px;
			font-weight: bold;
		}

		.close-button:focus {
			color: #000;
			text-decoration: none;
			cursor: pointer;
		}

		.cart-item {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 10px 0;
		}

		.cart-item:last-child {
			border-bottom: none;
		}

		.delete-btn {
			background-color: #dc3545;
			color: white;
			border: none;
			padding: 5px 10px;
			cursor: pointer;
			border-radius: 5px;
		}

		.delete-btn:hover {
			background-color: #c82333;
		}

		.checkout-btn, .continue-shopping-btn {
			padding: 10px 20px;
			margin: 5px;
			border: none;
			color: white;
			cursor: pointer;
			border-radius: 5px;
		}

				.checkout-btn {
			background-color: #007bff;
		}

		.continue-shopping-btn {
			background-color: #28a745;
		}

		.checkout-btn:hover {
			background-color: #0056b3;
		}

		.continue-shopping-btn:hover {
			background-color: #218838;
		}
		.grid-container {
			display: grid;
			grid-template-columns: repeat(5, 1fr);
			gap: 30px;
			padding: 20px;
			margin: auto;
		}
</style>

</head>
<body>
<header>
    <div class="logo-container">
        <img src="img/logoo1.png" alt="Webshop Logo">
    </div>
    <div class="cart-icon" id="cartIcon" onclick="toggleCart()">🛒 Kosaram</div>
	<div class="cart-overlay">
</div>
<div id="cartModal" class="modal" style="display:none;">
    <div class="modal-content">
        <span class="close-button" onclick="toggleCart()">✖</span>
        <h2>Kosár Tartalma</h2>
        <div class="cart-content">
        </div>
<div class="cart-actions">
    <button onclick="proceedToCheckout()" class="checkout-btn">Tovább a fizetéshez</button>
    <button onclick="toggleCart()" class="continue-shopping-btn">Tovább keresgélek</button>
</div>
    </div>
</div>
</header>
<nav>
    <a href="fooldal.php">Főoldal</a>
    <a href="kesztermek.php">Kész Termékek</a>
    <a href="disztermek.php">Dísztermékek</a>
    <a href="rolunk.php">Rólunk</a>
    <a href="kapcsolat.php">Kapcsolat</a>
    <?php if(isset($_SESSION['username'])): ?>
        Bejelentkezve: <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>
        <a href="logout.php">Kijelentkezés</a>
    <?php else: ?>
        <a href="login.php">Bejelentkezés</a>
        <a href="register.php">Regisztráció</a>
    <?php endif; ?>
</nav>
<div class="grid-container">
    <?php while($row = $result_keszleten->fetch_assoc()): ?>
    <div class="product">
        <img src="<?php echo $row['termek_kep']; ?>" alt="<?php echo $row['termek_nev']; ?>" style="width:100%;">
        <h3><?php echo $row['termek_nev']; ?></h3>
        <p><?php echo $row['termek_leiras']; ?></p>
        <p>Ár: <?php echo $row['termek_ar']; ?> Ft</p>
        <p>Készleten: <?php echo $row['keszleten']; ?> db</p>
        <button onclick="addToCart('<?php echo $row['termek_nev']; ?>', <?php echo $row['termek_ar']; ?>, <?php echo $row['keszleten']; ?>, '0', '0', '0')">Kosárba</button>
    </div>
    <?php endwhile; ?>
</div>
<script>
let cart = [];

function addToCart(productName, productPrice, productKeszleten, width, height, length) {
    let dimensions = '';
    if (width && height && length) {
        dimensions = `${width}x${height}x${length}`;
    }
    const product = { name: productName, price: productPrice, dimensions: dimensions, keszleten: productKeszleten };
    const existingProductIndex = cart.findIndex(item => item.name === productName && item.dimensions === dimensions);

    if (existingProductIndex !== -1) {
        if (cart[existingProductIndex].quantity < cart[existingProductIndex].keszleten) {
            cart[existingProductIndex].quantity += 1;
        } else {
            alert('Nincs több termék készleten.');
            return;
        }
    } else {
        if (productKeszleten > 0) {
            product.quantity = 1;
            cart.push(product);
        } else {
            alert('A termék nem elérhető.');
            return;
        }
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartUI();
}


function removeFromCart(productName, dimensions) {
    const index = cart.findIndex(item => item.name === productName && item.dimensions === dimensions);
    if (index !== -1) {
        cart.splice(index, 1);
        localStorage.setItem('cart', JSON.stringify(cart));
        updateCartUI();
    }
}

function updateCartUI() {
    const cartItemsElement = document.querySelector('.cart-content');
    if (!cartItemsElement) {
        console.error("Nem található .cart-content elem az oldalon!");
        return;
    }
    cartItemsElement.innerHTML = '<span class="close-cart" onclick="toggleCart()">✖</span><h2>Kosár Tartalma</h2>';
    let total = 0;
    cart.forEach(item => {
        const itemElement = document.createElement('div');
        itemElement.className = 'cart-item';
        itemElement.innerHTML = `${item.name} - ${item.quantity} db - Ára: ${item.quantity * item.price} Ft`;
        cartItemsElement.appendChild(itemElement);
        total += item.quantity * item.price;

        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Töröl';
        deleteButton.className = 'delete-btn';
        deleteButton.onclick = function() { removeFromCart(item.name, item.dimensions); };
        itemElement.appendChild(deleteButton);
    });

    const totalElement = document.createElement('p');
    totalElement.innerHTML = `Összesen: <span id='cartTotal'>${total}</span> Ft`;
    cartItemsElement.appendChild(totalElement);
}

function toggleCart() {
    const cartModal = document.getElementById('cartModal');
    if (cartModal.style.display === "none" || !cartModal.style.display) {
        cartModal.style.display = "block";
    } else {
        cartModal.style.display = "none";
    }
}


document.addEventListener('DOMContentLoaded', function() {
    const addToCartButtons = document.querySelectorAll('.add-to-cart-button');
    addToCartButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            const productName = this.dataset.name;
            const productPrice = parseFloat(this.dataset.price);
            const width = this.dataset.width || 0;
            const height = this.dataset.height || 0;
            const length = this.dataset.length || 0;
            addToCart(productName, productPrice, width, height, length);
        });
    });

    const storedCart = localStorage.getItem('cart');
    if (storedCart) {
        cart = JSON.parse(storedCart);
        updateCartUI();
    }
});
function proceedToCheckout() {
    // Átirányítás a fizetes.php oldalra
    window.location.href = "fizetes.php";
}
</script>
</body>
</html>
