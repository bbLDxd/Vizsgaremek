<?php
if (isset($_GET['fooldal'])){
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "users";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    }
    $sql_keszleten = "SELECT * FROM termekek";
    $result_keszleten = $conn->query($sql_keszleten);
    echo json_encode($result_keszleten);
}