<?php
include('auth.php');
$conn = new mysqli('localhost', 'root', '', 'users');

$success = $error = '';
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['username']) && isset($_POST['password'])) {
    $username = trim($_POST['username']);
    $password = password_hash(trim($_POST['password']), PASSWORD_DEFAULT);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $stmt = $conn->prepare("SELECT id FROM admin_users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $error = 'Ez a felhasználónév már foglalt.';
    } else {

        $stmt = $conn->prepare("INSERT INTO admin_users (username, password) VALUES (?, ?)");
        $stmt->bind_param("ss", $username, $password);
        if ($stmt->execute()) {
            $success = 'Az admin felhasználó sikeresen létrehozva.';
        } else {
            $error = 'Hiba történt a felhasználó létrehozása közben.';
        }
    }
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Admin létrehozás</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <style>
        body {
            background-color: #343a40;
            color: #ffffff;
        }
        .container {
            background-color: #23272b;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .form-group label {
            color: #ffffff;
        }
        .form-control {
            background-color: #23272b;
            border: 1px solid #555;
            color: #ffffff;
        }
        ::placeholder {
            color: #ddd;
        }
        .form-control:focus {
            background-color: #23272b;
            border-color: #007bff;
            color: #ffffff;
        }
        .btn-primary {
            background-color: #007bff;
            border: none;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        .navbar {
            background-color: #007bff;
        }
        .navbar-brand, .nav-link {
            color: #ffffff !important;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <a class="navbar-brand" href="#">Admin Felület</a>
    <div class="navbar-nav">
		<a class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'admin.php.') ? 'active' : ''; ?>" href="admin.php">Admin főoldal</a>
        <a class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'termek_hozzadas.php') ? 'active' : ''; ?>" href="termek_hozzadas.php">Új Termék hozzáadás</a>
        <a class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'termekek_listazasa.php') ? 'active' : ''; ?>" href="termekek_listazasa.php">Termékek listája/Módosítása</a>
		<a class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'felhasznalok_listazasa.php') ? 'active' : ''; ?>" href="felhasznalok_listazasa.php">Felhasználók listája</a>
        <a class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'admincreate.php') ? 'active' : ''; ?>" href="admincreate.php">Admin létrehozása</a>
    </div>
    <form class="form-inline" action="admin_kijelentkezes.php" method="post">
        <button class="btn btn-outline-light my-2 my-sm-0" type="submit">Kijelentkezés</button>
    </form>
</nav>
<body>
<div class="container">
    <h2>Admin Felhasználó Létrehozása</h2>
    <?php if ($success): ?>
        <div class="alert alert-success" role="alert"><?= $success ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger" role="alert"><?= $error ?></div>
    <?php endif; ?>
    <form action="" method="post">
        <div class="form-group">
            <label for="username">Felhasználónév</label>
            <input type="text" class="form-control" id="username" name="username" required>
        </div>
        <div class="form-group">
            <label for="password">Jelszó</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>
        <button type="submit" class="btn btn-primary">Létrehozás</button>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.8/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn
bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

</body>
</html>
