<?php
$db = new mysqli('localhost', 'root', '', 'users');

if (isset($_SESSION['userid'])) {
    $userid = $_SESSION['userid'];
    $query = $db->prepare("SELECT * FROM users WHERE id = ?");
    $query->bind_param('i', $userid);
    $query->execute();
    $result = $query->get_result();
    $user = $result->fetch_assoc();

    echo '
    <input type="text" id="vezeteknev" name="vezeteknev" value="' . $user['vezeteknev'] . '" required>
    <input type="text" id="keresztnev" name="keresztnev" value="' . $user['keresztnev'] . '" required>
    <input type="text" id="lakcim" name="lakcim" value="' . $user['lakcim'] . '" required>
    <input type="tel" id="telefonszam" name="telefonszam" value="' . $user['telefonszam'] . '" required>
    <input type="email" id="email" name="email" value="' . $user['email'] . '" required>
    ';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Fizetés és Szállítás</title>
<style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-image: url('img/hatterkaka1.png');
        background-size: cover;
        padding: 20px;
        color: #333;
    }
    .container {
        display: flex;
        max-width: 1200px;
        margin: auto;
        background-color: rgba(255, 255, 255, 0.9);
        border-radius: 15px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    .order-summary, .form-container {
        flex: 1;
        padding: 20px;
    }
    .form-section h3, .order-summary h3 {
        color: #0056b3;
    }
	.form-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 20px;
}

    input, select, button {
    width: 50%;
    padding: 10px;
    margin: 10px auto;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-sizing: border-box;
}
    button {
        background-color: #4CAF50;
        color: white;
        cursor: pointer;
        border: none;
    }
    button:hover {
        background-color: #45a049;
    }
    .order-summary ul {
        list-style-type: none;
        padding: 0;
    }
    .order-summary ul li {
        padding: 10px;
        border-bottom: 1px solid #ccc;
    }
    .total {
        font-weight: bold;
        margin-top: 20px;
    }
</style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <form id="payment-form" action="fizetes_feldolgozas.php" method="POST">
                <div class="form-section">
                    <h3>Szállítási és Fizetési Információ</h3>
                <input type="text" id="lastname" name="lastname" placeholder="Vezetéknév" required>
                <input type="text" id="firstname" name="firstname" placeholder="Keresztnév" required>
                <input type="email" id="email" name="email" placeholder="Email cím" required>
                <input type="tel" id="phone" name="phone" placeholder="Telefonszám" pattern="\+[0-9]+" required>
                <input type="text" id="taxnumber" name="taxnumber" placeholder="Adószám">
                <input type="text" id="city" name="city" placeholder="Város" required>
                <input type="text" id="street" name="street" placeholder="Utca" required>
                <input type="text" id="zipcode" name="zipcode" placeholder="Irányítószám" pattern="[0-9]+" required>
                <select name="shipping-method" required>
                        <option value="">Válassz szállítási módot...</option>
                        <option value="personal">Személyes átvétel</option>
                        <option value="posta">Postai szállítás</option>
                        <option value="courier">Futárszolgálat</option>
                        <option value="pickup">Csomagpont</option>
                    </select>
                    <select name="payment-method" id="payment-method" required>
                        <option value="">Válasszon fizetési módot...</option>
                        <option value="cash">Készpénz</option>
                        <option value="transfer">Banki átutalás</option>
                        <option value="card" disabled>Bankkártya (technikai okok miatt nem lehetséges)</option>
                        <option value="paypal" disabled>PayPal (technikai okok miatt nem lehetséges)</option>
                    </select>
                </div>
            </form>
        </div>
        <div class="order-summary">
            <h3>Kosár Tartalma</h3>
            <ul id="cartItems"></ul>
            </ul>
                <div class="total">Összesen: <span id="cartTotal"></span> Ft</div>
                <button type="button" onclick="proceedToPaymentPage()" class="proceed-to-payment-btn">Tovább a fizetési oldalra</button>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const cart = JSON.parse(localStorage.getItem('cart')) || [];
            let cartHtml = '';
            let total = 0;
            cart.forEach(function(item) {
                total += item.price * item.quantity;
                cartHtml += `<li>${item.name} - ${item.quantity} db - Ár: ${item.price} Ft/db</li>`;
            });
            document.getElementById('cartItems').innerHTML = cartHtml;
            document.getElementById('cartTotal').textContent = `${total} Ft`;
        });
    </script>

</body>
</html>