<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
include('auth.php');
require_once 'db_config.php';

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];

    $sql_update = "UPDATE users SET vegleges_kitiltva = 0 WHERE id = ?";
    if($stmt_update = $conn->prepare($sql_update)) {
        $stmt_update->bind_param("i", $id);
        if($stmt_update->execute()) {
            echo "A felhasználó végleges kitiltása sikeresen feloldva.";
        } else {
            echo "Hiba történt a végleges kitiltás feloldása során: " . $stmt_update->error;
        }
        $stmt_update->close();
    } else {
        echo "Nem sikerült előkészíteni az SQL frissítést: " . $conn->error;
    }
} else {
    echo "Hibás kérés. A kitiltás feloldásához szükséges egy érvényes felhasználói ID.";
}
$conn->close();
?>
