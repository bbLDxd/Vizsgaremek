declare namespace _default {
    const POINTERMOVE: string;
    const POINTERDOWN: string;
    const POINTERUP: string;
    const POINTEROVER: string;
    const POINTEROUT: string;
    const POINTERENTER: string;
    const POINTERLEAVE: string;
    const POINTERCANCEL: string;
}
export default _default;
//# sourceMappingURL=EventType.d.ts.map