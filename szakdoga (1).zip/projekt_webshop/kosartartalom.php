<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kosár Tartalom</title>
    <style>
        /* CSS stílusok itt... */
    </style>
</head>

<body>
    <h2>Kosár Tartalom</h2>
    <div id="cartContent"></div>
    <button onclick="proceedToCheckout()">Tovább a fizetéshez</button>

    <script>
        var cart = [];

        function displayCartContent() {
            var cartContentElement = document.getElementById('cartContent');
            if (cart.length === 0) {
                cartContentElement.innerHTML = "<p>A kosár üres.</p>";
            } else {
                var content = "<ul>";
                for (var i = 0; i < cart.length; i++) {
                    content += "<li>" + cart[i].name + " - " + cart[i].quantity + " db</li>";
                }
                content += "</ul>";
                cartContentElement.innerHTML = content;
            }
        }

        function proceedToCheckout() {
            alert("Fizetési folyamat megkezdése...");
        }

        displayCartContent();
    </script>
</body>

</html>
