<?php
include 'db_config.php';
date_default_timezone_set('Europe/Budapest');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $jelszo = $_POST["jelszo"];

    $sql = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $sql->bind_param("s", $email);
    $sql->execute();
    $result = $sql->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($jelszo, $row["jelszo"])) {
            if (!empty($row['ban_vege']) && new DateTime() < new DateTime($row['ban_vege'])) {
                echo "<div class='error-message'>A felhasználói fiók jelenleg korlátozva van. Korlátozva: " . $row['ban_vege'] . "</div>";
            } elseif ($row['vegleges_kitiltva'] == 1) {
                echo "<div class='error-message'>A felhasználói fiók véglegesen ki van tiltva.</div>";
            } else {
                session_start();
                $_SESSION["username"] = $row["vezeteknev"] . ' ' . $row["keresztnev"];
                header("Location: fooldal.php");
                exit();
            }
        } else {
            echo "<div class='error-message'>Hibás jelszó!</div>";
        }
    } else {
        echo "<div class='error-message'>Nincs ilyen felhasználó!</div>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="hu">
</html>


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bejelentkezés</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('img/hatterkaka1.png');
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-position: center center;
            background-color: #f4f4f4;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }

        .login-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            box-sizing: border-box;
        }

        button {
            background-color: #333;
            color: #ff1f;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
        }

        .error-message {
            color: white;
            text-align: center;
            margin-top: 10px;
        }
		.error-message {
			background-color: red;
			color: white;
			padding: 10px;
			margin: 10px 0;
		}
		.admin-login-btn {
            background-color: #007bff;
            color: white;
            margin-top: 20px;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
        }
    </style>
</head>

<body>
    <div class="login-container">
        <h2>Bejelentkezés</h2>
        <?php
        if (isset($error_message)) {
            echo "<p class='error-message'>$error_message</p>";
        }
        ?>
        <form action="" method="post">
            <label for="email">Email cím:</label>
            <input type="email" id="email" name="email" required>

            <label for="jelszo">Jelszó:</label>
            <input type="password" id="jelszo" name="jelszo" required>

            <button type="submit">Bejelentkezés</button>
			<a href="admin.php" style="text-decoration: none;">
            <button type="button" class="admin-login-btn">Admin Bejelentkezés</button>
        </form>
    </div>
</body>

</html>
