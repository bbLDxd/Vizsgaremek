<?php
include('auth.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    include 'db_config.php';
    $sql = "SELECT * FROM admin_users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row["password"])) {
            $_SESSION["loggedin"] = true;
            $_SESSION["username"] = $username;
            header("Location: admin_felulet.php");
            exit;
        } else {
            $login_err = "Hibás felhasználónév vagy jelszó!";
        }
    } else {
        $login_err = "Hibás felhasználónév vagy jelszó!";
    }
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Admin Felület</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <style>
        body {
            background-color: #343a40;
            color: #ffffff;
        }
        .navbar {
            background-color: #007bff;
        }
        .navbar-brand, .nav-link {
            color: #ffffff !important;
        }
        .nav-link.active {
            background-color: #0056b3 !important;
        }
        .main-content {
            padding: 20px;
        }
        .card {
            background-color: #23272b;
            border: none;
        }
        .btn-primary {
            background-color: #0069d9;
            border: none;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <a class="navbar-brand" href="#">Admin Felület</a>
    <div class="navbar-nav">
		<a class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'admin.php') ? 'active' : ''; ?>" href="admin.php">Admin főoldal</a>
        <a class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'termek_hozzadas.php') ? 'active' : ''; ?>" href="termek_hozzadas.php">Új Termék hozzáadás</a>
        <a class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'termekek_listazasa.php') ? 'active' : ''; ?>" href="termekek_listazasa.php">Termékek listája/Módosítása</a>
        <a class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'felhasznalok_listazasa.php') ? 'active' : ''; ?>" href="felhasznalok_listazasa.php">Felhasználók listája</a>
        <a class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'admincreate.php') ? 'active' : ''; ?>" href="admincreate.php">Admin létrehozása</a>
    </div>
    <form class="form-inline" action="admin_kijelentkezes.php" method="post">
        <button class="btn btn-outline-light my-2 my-sm-0" type="submit">Kijelentkezés</button>
    </form>
</nav>
<body>
<div class="container mt-3">
    <div class="row">
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Legtöbbet Megvásárolt Termék</h5>
                    <p></p>
                </div>
            </div>
        </div>
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Legtöbbet Böngészett Termék</h5>
                    <p></p>
                    <p></p>
                </div>
            </div>
        </div>
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Átlagos Kosárérték</h5>
                    <p></p>
                </div>
            </div>
        </div>
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Új Felhasználók Száma</h5>
                    <p></p>
                </div>
            </div>
        </div>
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Visszatérő Felhasználók Aránya</h5>
                    
                </div>
            </div>
        </div>


<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.10/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</body>
</html>