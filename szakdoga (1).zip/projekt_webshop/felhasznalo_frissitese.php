<?php
include('auth.php');
$conn = new mysqli('localhost', 'root', '', 'users');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = $_POST['id'] ?? null;
$vezeteknev = $_POST['vezeteknev'] ?? '';
$keresztnev = $_POST['keresztnev'] ?? '';
$lakcim = $_POST['lakcim'] ?? '';
$telefonszam = $_POST['telefonszam'] ?? '';
$email = $_POST['email'] ?? '';

if ($id) {
    $stmt = $conn->prepare("UPDATE users SET vezeteknev = ?, keresztnev = ?, lakcim = ?, telefonszam = ?, email = ? WHERE id = ?");
    $stmt->bind_param("sssssi", $vezeteknev, $keresztnev, $lakcim, $telefonszam, $email, $id);

    if ($stmt->execute()) {
        echo "A felhasználó adatai sikeresen frissítve.";
        header("Location: felhasznalok_listazasa.php");
        exit();
    } else {
        echo "Hiba történt: " . $conn->error;
    }
} else {
    echo "Nincs megadva felhasználói azonosító.";
}

$conn->close();
?>