<?php
include('auth.php');
	$conn = new mysqli('localhost', 'root', '', 'users');

	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}

	$id = isset($_GET['id']) ? (int) $_GET['id'] : null;

	if (!$id) {
		echo "Nincs megadva id.";
		exit;
	}

	$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
	$stmt->bind_param("i", $id);
	$stmt->execute();
	$result = $stmt->get_result();

	if (!$user = $result->fetch_assoc()) {
		echo "Nincs ilyen id-jű felhasználó.";
		exit;
	}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Felhasználó Szerkesztése</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <style>
        body {
            background-color: #343a40;
            color: #ffffff;
        }
        .container {
            background-color: #23272b;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .form-group label {
            color: #ffffff;
        }
        .form-control {
            background-color: #23272b;
            border: 1px solid #555;
            color: #ffffff;
        }
        ::placeholder {
            color: #ddd;
        }
        .form-control:focus {
            background-color: #23272b;
            border-color: #007bff;
            color: #ffffff;
        }
        .btn-primary {
            background-color: #007bff;
            border: none;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        .navbar {
            background-color: #007bff;
        }
        .navbar-brand, .nav-link {
            color: #ffffff !important;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <a class="navbar-brand" href="#">Admin Felület</a>
    <div class="navbar-nav">
		<a class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'admin.php.') ? 'active' : ''; ?>" href="admin.php">Admin főoldal</a>
        <a class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'termek_hozzadas.php') ? 'active' : ''; ?>" href="termek_hozzadas.php">Új Termék hozzáadás</a>
        <a class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'termekek_listazasa.php') ? 'active' : ''; ?>" href="termekek_listazasa.php">Termékek listája/Módosítása</a>
        <a class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'admincreate.php') ? 'active' : ''; ?>" href="admincreate.php">Admin létrehozása</a>
    </div>
    <span class="navbar-text">
        Bejelentkezve:  <?php echo $felhasznalo_neve; ?>
    </span>
    <form class="form-inline" action="admin_kijelentkezes.php" method="post">
        <button class="btn btn-outline-light my-2 my-sm-0" type="submit">Kijelentkezés</button>
    </form>
</nav>

<div class="container">
    <h2>Felhasználó Szerkesztése</h2>
<form action="felhasznalo_frissitese.php" method="post">
    <input type="hidden" name="id" value="<?= htmlspecialchars($user['id']) ?>">

    <div class="form-group">
        <label for="vezeteknev">Vezetéknév</label>
        <input type="text" class="form-control" id="vezeteknev" name="vezeteknev" value="<?= htmlspecialchars($user['vezeteknev']) ?>" required>
    </div>

    <div class="form-group">
        <label for="keresztnev">Keresztnév</label>
        <input type="text" class="form-control" id="keresztnev" name="keresztnev" value="<?= htmlspecialchars($user['keresztnev']) ?>" required>
    </div>

    <div class="form-group">
        <label for="lakcim">Lakcím</label>
        <input type="text" class="form-control" id="lakcim" name="lakcim" value="<?= htmlspecialchars($user['lakcim']) ?>" required>
    </div>

    <div class="form-group">
        <label for="telefonszam">Telefonszám</label>
        <input type="text" class="form-control" id="telefonszam" name="telefonszam" value="<?= htmlspecialchars($user['telefonszam']) ?>" required>
    </div>

    <div class="form-group">
        <label for="email">Email</label>
        <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
    </div>
		
    <button type="submit" class="btn btn-primary">Frissítés</button>
</form>
</div>
</body>
</html>