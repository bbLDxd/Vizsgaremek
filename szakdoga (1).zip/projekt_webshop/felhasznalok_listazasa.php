<?php
include('auth.php');
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "users";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT id, vezeteknev, keresztnev, lakcim, telefonszam, email FROM users";

$result = $conn->query($sql);

if ($result === false) {
    die("Hiba történt: " . $conn->error);
}

$users = [];
while ($row = $result->fetch_assoc()) {
    $users[] = $row;
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Felhasználók Listázása</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <style>
        body {
            background-color: #343a40;
            color: #ffffff;
        }
        .navbar {
            background-color: #007bff;
        }
        .navbar-brand, .nav-link {
            color: #ffffff !important;
        }
        .nav-link.active {
            background-color: #0056b3 !important;
            color: white !important;
        }
        .container {
            background: #23272b;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,.1);
        }
        .table th, .table td {
            color: #ffffff;
        }
        .btn-primary {
            background-color: #0069d9;
            border: none;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
    </style>

</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <a class="navbar-brand" href="#">Admin Felület</a>
    <div class="navbar-nav">
        <a class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'admin.php') ? 'active' : ''; ?>" href="admin.php">Admin főoldal</a>
        <a class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'termek_hozzadas.php') ? 'active' : ''; ?>" href="termek_hozzadas.php">Új Termék hozzáadás</a>
        <a class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'termekek_listazasa.php') ? 'active' : ''; ?>" href="termekek_listazasa.php">Termékek listája/Módosítása</a>
        <a class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'felhasznalok_listazasa.php') ? 'active' : ''; ?>" href="felhasznalok_listazasa.php">Felhasználók listája</a>
        <a class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'admincreate.php') ? 'active' : ''; ?>" href="admincreate.php">Admin létrehozása</a>
    </div>
    <form class="form-inline" action="admin_kijelentkezes.php" method="post">
        <button class="btn btn-outline-light my-2 my-sm-0" type="submit">Kijelentkezés</button>
    </form>
</nav>

<div class="container-fluid">
    <h2>Felhasználók Listázása</h2>
    <table class="table">
        <thead>
            <tr>
                <th>Vezetéknév</th>
                <th>Keresztnév</th>
                <th>Lakcím</th>
                <th>Telefonszám</th>
                <th>Email</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
                <tr>
                    <td><?= htmlspecialchars($user['vezeteknev']) ?></td>
                    <td><?= htmlspecialchars($user['keresztnev']) ?></td>
                    <td><?= htmlspecialchars($user['lakcim']) ?></td>
                    <td><?= htmlspecialchars($user['telefonszam']) ?></td>
                    <td><?= htmlspecialchars($user['email']) ?></td>
                    <td>
                        <a href="felhasznalo_szerkesztese.php?id=<?= htmlspecialchars($user['id']) ?>" class="btn btn-primary">Szerkeszt</a>
                        <a href="felhasznalo_torles.php?id=<?= htmlspecialchars($user['id']) ?>" class="btn btn-danger" onclick="return confirm('FIGYELEM! Ezzel TÖRLÖD a felhasználót az adatbázisból!!!');">Törlés</a>
                        <a href="felhasznalo_ban.php?id=<?= htmlspecialchars($user['id']) ?>" class="btn btn-danger" onclick="return confirm('FIGYELEM! Ezzel VÉGLEG KITILTOD a felhasználót az adatbázisból!!!');">Perma Ban</a>
						<a href="felhasznalo_korlatozas.php?id=<?= htmlspecialchars($user['id']) ?>" class="btn btn-warning">Korlátozás</a>
						<a href="felhasznalo_korlatozas_feloldas.php?id=<?= htmlspecialchars($user['id']) ?>" class="btn btn-success" onclick="return confirm('Biztosan feloldod a korlátozást?');">
						Korlátozás feloldása</a>
						<a href="felhasznalo_kitiltas_feloldas.php?id=<?= htmlspecialchars($user['id']) ?>" class="btn btn-success" onclick="return confirm('Biztosan feloldod a kitiltást?');">Kitiltás feloldása</a>


                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.10/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</body>
</html>
