<?php
include('auth.php');
require_once 'db_config.php';

if(isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];

    $sql_check = "SELECT vegleges_kitiltva FROM users WHERE id = ?";
    if($stmt_check = $conn->prepare($sql_check)) {
        $stmt_check->bind_param("i", $id);
        if($stmt_check->execute()) {
            $stmt_check->store_result();
            if($stmt_check->num_rows > 0) {
                $stmt_check->bind_result($vegleges_kitiltva);
                $stmt_check->fetch();
                if($vegleges_kitiltva == 1) {
                    die("Ez a felhasználó már véglegesen ki van tiltva.");
                }
            } else {
                die("Nem található felhasználó ezzel az azonosítóval.");
            }
        } else {
            die("Hiba történt a lekérdezés végrehajtása során: " . $stmt_check->error);
        }
        $stmt_check->close();
    } else {
        die("Nem sikerült előkészíteni az SQL lekérdezést: " . $conn->error);
    }

    $sql_update = "UPDATE users SET ban_vege = NULL, vegleges_kitiltva = 1 WHERE id = ?";
    if($stmt_update = $conn->prepare($sql_update)) {
        $stmt_update->bind_param("i", $id);
        if($stmt_update->execute()) {
            echo "A felhasználó véglegesen ki lett tiltva.";
        } else {
            die("Hiba történt a frissítés során: " . $stmt_update->error);
        }
        $stmt_update->close();
    } else {
        die("Nem sikerült előkészíteni az SQL frissítést: " . $conn->error);
    }

    header('Location: felhasznalok_listazasa.php');
    exit();
} else {
    die("Hibás kérés.");
}
?>

