<?php
require_once 'db_config.php';

if (isset($_GET['termek_id'])) {
    $termek_id = $_GET['termek_id'];

    $sql = "SELECT termek_nev, termek_keszlet FROM termekek WHERE termek_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $termek_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $termek_nev = $row['termek_nev'];
        $aktualis_keszlet = $row['termek_keszlet'];
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['modosit'])) {
    $uj_keszlet = $_POST['uj_keszlet'];
    $updateSql = "UPDATE termekek SET termek_keszlet = ? WHERE termek_id = ?";
    $stmt = $conn->prepare($updateSql);
    $stmt->bind_param("ii", $uj_keszlet, $termek_id);
    
    if ($stmt->execute()) {
        echo "<script>alert('Készlet sikeresen frissítve.'); window.location.href='termekek_listazasa.php';</script>";
    } else {
        echo "Hiba: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Készlet Módosítása</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <h2>Készlet Módosítása - <?php echo $termek_nev; ?></h2>
    <form method="post">
        <div class="form-group">
            <label for="uj_keszlet">Új Készlet:</label>
            <input type="number" class="form-control" id="uj_keszlet" name="uj_keszlet" value="<?php echo $aktualis_keszlet; ?>" required>
        </div>
        <button type="submit" name="modosit" class="btn btn-primary">Módosít</button>
    </form>
</div>
</body>
</html>
