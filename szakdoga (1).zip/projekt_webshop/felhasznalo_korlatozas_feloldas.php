<?php
include('auth.php');
require_once 'db_config.php';

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "UPDATE users SET ban_vege = NULL WHERE id = ?";

    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            echo "A korlátozás sikeresen feloldva.";
        } else {
            echo "Hiba történt a korlátozás feloldása során: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Nem sikerült előkészíteni az SQL utasítást.";
    }

    $conn->close();
} else {
    echo "Hibás kérés.";
}

header('Location: felhasznalok_listazasa.php');
exit();
?>
