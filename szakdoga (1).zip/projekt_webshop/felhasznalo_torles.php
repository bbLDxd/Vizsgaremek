<?php
include('auth.php');
require_once 'db_config.php';

if(isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];
    
    $sql = "DELETE FROM users WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        echo "A felhasználó sikeresen törölve.";
    } else {
        echo "Hiba történt a törlés során: " . $conn->error;
    }
    
    $conn->close();
} else {
    echo "Hibás kérés.";
}
header('Location: felhasznalok_listazasa.php');
exit();
?>
