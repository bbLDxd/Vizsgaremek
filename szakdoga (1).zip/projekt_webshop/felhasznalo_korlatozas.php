<?php
include('auth.php');
require_once 'db_config.php';
date_default_timezone_set('Europe/Budapest');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'] ?? null;
    $ban_vege = $_POST['ban_vege'] ?? null;

    if(isset($id) && is_numeric($id) && isset($ban_vege)) {
        $sql_update = "UPDATE users SET ban_vege = ? WHERE id = ?";
        if($stmt_update = $conn->prepare($sql_update)) {
            $stmt_update->bind_param("si", $ban_vege, $id);
            if($stmt_update->execute()) {
                echo "A felhasználó sikeresen korlátozva " . $ban_vege . "-ig.";
            } else {
                echo "Hiba történt a korlátozás során: " . $stmt_update->error;
            }
            $stmt_update->close();
        } else {
            echo "Nem sikerült előkészíteni az SQL frissítést: " . $conn->error;
        }
        $conn->close();
    } else {
        echo "Hibás kérés.";
    }
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Felhasználók Listázása</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <style>
        body {
            background-color: #343a40;
            color: #ffffff;
        }
        .navbar {
            background-color: #007bff;
        }
        .navbar-brand, .nav-link {
            color: #ffffff !important;
        }
        .nav-link.active {
            background-color: #0056b3 !important;
            color: white !important;
        }
        .container {
            background: #23272b;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,.1);
        }
        .table th, .table td {
            color: #ffffff;
        }
        .btn-primary {
            background-color: #0069d9;
            border: none;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
    </style>

</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <a class="navbar-brand" href="#">Admin Felület</a>
    <div class="navbar-nav">
        <a class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'termek_hozzadas.php') ? 'active' : ''; ?>" href="termek_hozzadas.php">Új Termék hozzáadás</a>
        <a class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'termekek_listazasa.php') ? 'active' : ''; ?>" href="termekek_listazasa.php">Termékek listája/Módosítása</a>
        <a class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'felhasznalok_listazasa.php') ? 'active' : ''; ?>" href="felhasznalok_listazasa.php">Felhasználók listája</a>
        <a class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'admincreate.php') ? 'active' : ''; ?>" href="admincreate.php">Admin létrehozása</a>
    </div>
    <form class="form-inline" action="admin_kijelentkezes.php" method="post">
        <button class="btn btn-outline-light my-2 my-sm-0" type="submit">Kijelentkezés</button>
    </form>
</nav>
<form action="felhasznalo_korlatozas.php?id=<?= htmlspecialchars($_GET['id'] ?? '') ?>" method="post">
    <input type="hidden" name="id" value="<?= htmlspecialchars($_GET['id'] ?? '') ?>">
    <label for="ban_vege">Korlátozás vége:</label>
    <input type="date" id="ban_vege" name="ban_vege" required>
    <button type="submit" class="btn btn-warning">Felhasználó korlátozása</button>
</form>
</body>
</html>
