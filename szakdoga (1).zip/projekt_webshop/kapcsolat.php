<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kapcsolat</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('img/hatterkaka1.png');
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-position: center center;
            background-color: #f4f4f4;
            padding-bottom: 50px;
        }

        header, footer {
            background-color: #808080;
            color: #fff;
            text-align: center;
            padding: 20px;
        }

        .logo-container img {
            height: 100px;
        }

        nav {
		display: flex;
		justify-content: center;
		background-color: #333;
		padding: 10px 0;
	}

	nav a {
		color: white;
		text-decoration: none;
		margin: 0 20px;
		font-weight: bold;
	}

        .contact-container {
            background-color: #fff;
            color: #333;
            padding: 20px;
            margin: 20px auto;
            max-width: 800px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .contact-container h2 {
            margin-bottom: 20px;
        }

        .contact-details {
            margin-bottom: 10px;
        }

        footer {
            background: #333;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            position: relative;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
<header>
    <div class="logo-container">
        <img src="img/logoo1.png" alt="Webshop Logo">
    </div>
</header>
<nav>
    <a href="fooldal.php">Főoldal</a>
    <a href="kesztermek.php">Kész Termékek</a>
    <a href="disztermek.php">Dísztermékek</a>
    <a href="rolunk.php">Rólunk</a>
    <a href="kapcsolat.php">Kapcsolat</a>
    <?php if(isset($_SESSION['username'])): ?>
        Bejelentkezve: <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>
        <a href="logout.php">Kijelentkezés</a>
    <?php else: ?>
        <a href="login.php">Bejelentkezés</a>
        <a href="register.php">Regisztráció</a>
    <?php endif; ?>
</nav>
<div class="contact-container">
    <h2>Kapcsolat</h2>
    <div class="contact-details">
        <p> Üdvözöljük a Wood Design Store-nál! Ha minőségi fa termékekre vágyik otthona vagy irodája számára, akkor nálunk a helye. Széles választékunkban megtalálhatók a különleges design bútorok, a praktikus dekorációs elemek és az egyedi kiegészítők. Bármilyen kérdése vagy kérés esetén állunk rendelkezésére, így ne habozzon kapcsolatba lépni velünk az alábbi elérhetőségeinken:</p>
        <p><strong>Telephely:</strong> 2222 Példaváros, Példa út 2.</p>
        <p><strong>Csomagpontok:</strong> Lista a csomagpontokról...</p>
        <p><strong>Alapító/Tulajdonos:</strong> Nagy Péter</p>
        <p><strong>Kapcsolattartó:</strong> Kovács Anna</p>
        <p><strong>Email:</strong> info@wooddesignstore.hu</p>
        <p><strong>Telefonszám:</strong> +36 1 234 5678 (Vezetékes), +36 30 123 4567 (Mobil)</p>
    </div>
</div>
</body>
</html>
