<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fizetés Feldolgozása</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('img/hatterkaka1.png');
            background-size: cover;
            padding: 20px;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .message-container {
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 15px;
            padding: 20px;
            text-align: center;
            max-width: 600px;
        }
        .back-button {
            display: inline-block;
            margin-top: 20px;
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }
    </style>
</head>
<body>

<div class="message-container">
    <h2>Köszönjük a bizalmát!</h2>
    <p>Hamarosan értesítjük emailben a szállítási információkról!</p>
    <a href="fooldal.php" class="back-button">Vissza a főoldalra</a>
</div>

</body>
</html>
